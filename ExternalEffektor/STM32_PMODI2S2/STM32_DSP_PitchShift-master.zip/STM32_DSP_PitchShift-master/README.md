# STM32 AUDIO DSP Pitch Shifting

I implemented a pitch-shifting algorithm on the STM32F407 with the help of a audio I/O board from digitalent (https://store.digilentinc.com/pmod-i2s2-stereo-audio-input-and-output/)

See my YouTube video for further details: https://youtu.be/p_a8mDcAvOg

For further details in the setup of the I2S and DMA hardware please refer to my first STM32 DSP video : https://youtu.be/lNBrGOk0XzE
